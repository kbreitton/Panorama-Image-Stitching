the images I used were myim1.jpg, myim2.jpg, and myim3.jpg. The final mosaic is my_mosaic.jpg

They were resized to 15% of their scale and put into img_input before running mymosaic.m

All the code for generating the images during the process is in mymosaic.m, just commented out currently
